import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://jyczlkxhcovqrpckwnor.supabase.co'
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp5Y3psa3hoY292cXJwY2t3bm9yIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODMyMjI3NjMsImV4cCI6MTk5ODc5ODc2M30.CUGY77hlgbGpU41LsylIM94FoybQCu2hz5QOtsKxan8"
const supabase = createClient(supabaseUrl, supabaseKey)
const table = 'stats'

class Card {
  constructor(name, value, suit) {
    this.name = name;
    this.value = value;
    this.suit = suit;
  }
}


// Array that stores all card values to the correct card
let cardsArr = [new Card("ace", 1, "spades"), new Card("two", 2, "spades"), new Card("three", 3, "spades"), new Card("four", 4, "spades"), new Card("five", 5, "spades"), new Card("six", 6, "spades"), new Card("seven", 7, "spades"), new Card("eight", 8, "spades"), new Card("nine", 9, "spades"), new Card("ten", 10, "spades"), new Card("jack", 10, "spades"), new Card("queen", 10, "spades"), new Card("king", 10, "spades"),
new Card("ace", 1, "hearts"), new Card("two", 2, "hearts"), new Card("three", 3, "hearts"), new Card("four", 4, "hearts"), new Card("five", 5, "hearts"), new Card("six", 6, "hearts"), new Card("seven", 7, "hearts"), new Card("eight", 8, "hearts"), new Card("nine", 9, "hearts"), new Card("ten", 10, "hearts"), new Card("jack", 10, "hearts"), new Card("queen", 10, "hearts"), new Card("king", 10, "hearts"),
new Card("ace", 1, "diamonds"), new Card("two", 2, "diamonds"), new Card("three", 3, "diamonds"), new Card("four", 4, "diamonds"), new Card("five", 5, "diamonds"), new Card("six", 6, "diamonds"), new Card("seven", 7, "diamonds"), new Card("eight", 8, "diamonds"), new Card("nine", 9, "diamonds"), new Card("ten", 10, "diamonds"), new Card("jack", 10, "diamonds"), new Card("queen", 10, "diamonds"), new Card("king", 10, "diamonds"),
new Card("ace", 1, "clubs"), new Card("two", 2, "clubs"), new Card("three", 3, "clubs"), new Card("four", 4, "clubs"), new Card("five", 5, "clubs"), new Card("six", 6, "clubs"), new Card("seven", 7, "clubs"), new Card("eight", 8, "clubs"), new Card("nine", 9, "clubs"), new Card("ten", 10, "clubs"), new Card("jack", 10, "clubs"), new Card("queen", 10, "clubs"), new Card("king", 10, "clubs")]


// Empty arrays that will hold the cards
let playerHand = []
let playerHandNames = []
let dealerHand = []
let dealerHandNames = []

// Shuffles deck
let shuffledDeck = shuffle(cardsArr);

// Deals dealers first card
let dealerCardOne = shuffledDeck.pop();
dealerHand.push(dealerCardOne);
dealerHandNames.push(dealerCardOne);

// Deals players starting hand
let playerCardOne = shuffledDeck.pop();
playerHand.push(playerCardOne);
let playerCardTwo = shuffledDeck.pop();
playerHand.push(playerCardTwo);


// Adds players hand together
let playerTotal = playerHand[0].value + playerHand[1].value;

// If start button clicked, begin game
let start = document.querySelector('#start');
start.addEventListener("click", await startGame)

// If hit button is clicked, add card to players hand.
let hit = document.querySelector('#hit')
hit.addEventListener("click", hitCard)

// If stand button is clicked, add dealers cards.
let stand = document.querySelector("#stand")
stand.addEventListener("click", standCard)

// If refresh button is clicked, refresh page
let refresh = document.querySelector("#refresh")
refresh.addEventListener("click", refreshPage)

// Statistics from HTML
let winStat = document.querySelector("#wins")
let loseStat = document.querySelector("#losses")
let stats = document.querySelector("#stats")
let resetButton = document.querySelector("#resetStats")


async function startGame() {
  // Shows hit and stand buttons on screen
  hit.style.display = "inline-block";
  stand.style.display = "inline-block";

  // Shows reset score button, and gives it a function.
  resetButton.style.visibility = "visible";
  resetButton.addEventListener("click", await resetStats);

  // Prints dealers first card on screen
  document.getElementById('dealerCards').innerHTML = "Dealers Cards: " + dealerHand[0].name

  // Prints players cards on screen
  document.getElementById('playerCards').innerHTML = "Players Cards: " + playerHand[0].name + " " + playerHand[1].name;

  // Prints players total on screen
  document.getElementById('playerEqual').innerHTML = "Total: " + playerTotal;

  // displays players cards when start is pressed
  checkCards(playerHand, displayImage);

  // displays players cards when start is pressed
  checkCards(dealerHand, displayCertainImage);

  stats.innerHTML = "Stats"
  let theScore = await getScore();
  winStat.innerHTML = "Wins: " + theScore["wins"];
  loseStat.innerHTML = "Losses: " + theScore["losses"];
}

// Function that gives player a card when hit is pressed
function hitCard() {
  let card = shuffledDeck.pop();
  playerHand.push(card);

  // Shows players hit card on screen
  checkLastCard(playerHand, displayImage);

  // For loop that holds the total and counts it if the cards are in the array
  let playerTotal = countTotal(playerHand, playerHandNames);

  // prints total on screen
  document.getElementById('playerEqual').innerHTML = "Total: " + playerTotal;

  // prints player cards on screen
  document.getElementById('playerCards').innerHTML = "Players Cards: " + playerHandNames;

  // INITITALLY determines if the player has won (21)
  if (playerTotal == 21) {
    winCondition();

    // INITITALLY determines if the player has lost (>21)
  } else if (playerTotal > 21) {
    loseCondition();
  }
}

// Function that gives dealer a new card when stand is pressed.
function standCard() {
  let card = shuffledDeck.pop();
  dealerHand.push(card);
  dealerHandNames.push(card);

  // Counts the total of the cards together
  let total = 0
  for (let i = 0; i < dealerHand.length; i++) {
    dealerHandNames[i] = dealerHand[i].name
    total = total + dealerHand[i].value
  }

  // Shows dealer total on screen
  let dealerTotal = document.querySelector("#dealerEqual")
  dealerTotal.innerHTML = "Total: " + total;

  // Shows dealer cards on screen
  let dealerCards = document.querySelector("#dealerCards")
  dealerCards.innerHTML = "Dealer Cards: " + dealerHandNames;

  // Show dealer Cards when stand is pressed
  checkLastCard(dealerHand, displaySecondImage)

  // Disables hit button when stand is first pressed
  hit.disabled = true;

  // Assigns player count to a variable
  let pCount = countTotal(playerHand, playerHandNames);

  // Conditions to win/lose the game
  if (total > pCount && total <= 21) {
    loseCondition();
  } else if (pCount < 21 && total > 21) {
    winCondition();
  } else if (total > 21) {
    loseCondition();
  } else if (total >= 17 && pCount > total && total < 21) {
    winCondition();
  } else if (total >= 17 && total < 21 && total > pCount) {
    loseCondition();
  } else if (total >= 17 && pCount == total) {
    tieCondition();
  }
}

// Function that refreshes the page
function refreshPage() {
  location.reload();
}

// Function that checks cards in array and prints correct one
function checkCards(person, func) {
  for (let i = 0; i < person.length; i++) {
    let c = "/assets/" + person[i].name + "_" + person[i].suit + ".png";
    func(c, 135, 200);
  }
}

// Function that checks the last card in a persons hand and shows it on screen
function checkLastCard(person, func) {
  let flipCard = person[person.length - 1];
  let c = "/assets/" + flipCard.name + "_" + flipCard.suit + ".png";
  func(c, 135, 200);
}


// Function that adds an array together
function sumArray(array) {
  let sum = 0;
  for (let i = 0; i < array.length; i += 1) {
    sum += array[i];
  }
  return sum;
}

// Function that displays players cards
function displayImage(src, width, height) {
  let img = document.createElement("img");
  img.src = src;
  img.width = width;
  img.height = height;
  document.body.appendChild(img);
}

// Function that displays dealers initial cards
function displayCertainImage(src, width, height) {
  let img = document.createElement("img");
  img.src = src;
  img.width = width;
  img.height = height;
  document.body.appendChild(img);
  let dealerPictureCards = document.getElementById("dealerPictureCards");
  dealerPictureCards.insertBefore(img, dealerPictureCards.children[0]);
}

// Function that displays dealers new cards
function displaySecondImage(src, width, height) {
  let img = document.createElement("img");
  img.src = src;
  img.width = width;
  img.height = height;
  document.body.appendChild(img);
  let dealerPictureCards = document.getElementById("dealerPictureCards");
  dealerPictureCards.insertAdjacentElement("beforeend", img);
}

// Condition that ends the game if player wins
async function winCondition() {
  // Changes screen to lose screen
  stand.disabled = true;
  hit.disabled = true;
  document.getElementById("end").innerHTML = "YOU WIN!"
  console.log("win")

  // Updates win to database.
  let playerData = await getScore();
  let newScore = playerData["wins"] + 1;
  await updateWin(newScore);
}

// Condition that ends the game if the player loses
async function loseCondition() {

  // Changes screen to lose screen
  stand.disabled = true;
  hit.disabled = true;
  document.getElementById("end").innerHTML = "YOU LOSE!"

  // Updates loss to database.
  let playerData = await getScore();
  let newScore = playerData["losses"] + 1;
  await updateLoss(newScore);
}

// Condition that ends the game if the player loses
function tieCondition() {
  stand.disabled = true;
  hit.disabled = true;
  document.getElementById("end").innerHTML = "YOU TIE!"
  console.log("tie")
}

// Function that counts a total based on given parameters
function countTotal(player, names) {
  let total = 0
  for (let i = 0; i < player.length; i++) {
    names[i] = player[i].name
    total = total + player[i].value
  }
  return total;
}

// Function that shuffles the deck of cards
function shuffle(arr) {
  var j, x, index;
  for (index = arr.length - 1; index > 0; index--) {
    j = Math.floor(Math.random() * (index + 1));
    x = arr[index];
    arr[index] = arr[j];
    arr[j] = x;
  }
  return arr;
}

// Function that reloads the tab
async function reloadTab() {
  location.reload();
}

// SUPABASE FUNCTIONS

async function getScore() {
  const { data, error } = await supabase
    .from(table)
    .select('id, wins, losses')
    .limit(1)
    .single()
  return data
}

async function addData(score) {

  const { error } = await supabase
    .from(table)
    .insert(
      {
        score: score
      }
    )
}

async function updateWin(winCount) {
  const { error } = await supabase
    .from(table)
    .update({ wins: winCount })
    .eq('id', 0)
}

async function updateLoss(lossCount) {
  const { error } = await supabase
    .from(table)
    .update({ losses: lossCount })
    .eq('id', 0)
}

async function resetStats() {
  const { error } = await supabase
    .from(table)
    .update({ wins: "0", losses: "0" })
    .eq('id', 0)
  await reloadTab()
}